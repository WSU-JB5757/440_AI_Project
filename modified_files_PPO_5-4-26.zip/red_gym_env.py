# this code was edited with ChatGPT
import sys
import uuid 
import os
from math import floor, sqrt
import json
from pathlib import Path

import numpy as np
from einops import rearrange
import matplotlib.pyplot as plt
from skimage.transform import resize
from pyboy import PyBoy
#from pyboy.logger import log_level
import hnswlib
import mediapy as media
import pandas as pd

from gymnasium import Env, spaces
from pyboy.utils import WindowEvent
from memory_addresses import *

class RedGymEnv(Env):


    def __init__(
        self, config=None):

        self.debug = config['debug']
        self.s_path = config['session_path']
        self.save_final_state = config['save_final_state']
        self.print_rewards = config['print_rewards']
        self.vec_dim = 4320 #1000
        self.headless = config['headless']
        self.num_elements = 20000 # max
        self.init_state = config['init_state']
        self.act_freq = config['action_freq']
        self.max_steps = config['max_steps']
        self.early_stopping = config['early_stop']
        self.save_video = config['save_video']
        self.fast_video = config['fast_video']
        self.video_interval = 256 * self.act_freq
        self.downsample_factor = 2
        self.frame_stacks = 3
        self.explore_weight = 1 if 'explore_weight' not in config else config['explore_weight']
        self.use_screen_explore = True if 'use_screen_explore' not in config else config['use_screen_explore']
        self.similar_frame_dist = config['sim_frame_dist']
        self.reward_scale = 1 if 'reward_scale' not in config else config['reward_scale']
        self.extra_buttons = False if 'extra_buttons' not in config else config['extra_buttons']
        self.instance_id = str(uuid.uuid4())[:8] if 'instance_id' not in config else config['instance_id']
        self.s_path.mkdir(exist_ok=True)
        self.reset_count = 0
        self.last_action = None
        self.last_heal_reward = 0
        self.last_death_penalty = 0
        self.all_runs = []

        # Set this in SOME subclasses
        self.metadata = {"render.modes": []}
        self.reward_range = (0, 15000)

        self.valid_actions = [
            WindowEvent.PRESS_ARROW_DOWN,
            WindowEvent.PRESS_ARROW_LEFT,
            WindowEvent.PRESS_ARROW_RIGHT,
            WindowEvent.PRESS_ARROW_UP,
            WindowEvent.PRESS_BUTTON_A,
            WindowEvent.PRESS_BUTTON_B,
        ]
        
        if self.extra_buttons:
            self.valid_actions.extend([
                WindowEvent.PRESS_BUTTON_START,
                WindowEvent.PASS
            ])

        self.release_arrow = [
            WindowEvent.RELEASE_ARROW_DOWN,
            WindowEvent.RELEASE_ARROW_LEFT,
            WindowEvent.RELEASE_ARROW_RIGHT,
            WindowEvent.RELEASE_ARROW_UP
        ]

        self.release_button = [
            WindowEvent.RELEASE_BUTTON_A,
            WindowEvent.RELEASE_BUTTON_B
        ]

        self.output_shape = (36, 40, 3)
        self.mem_padding = 2
        self.memory_height = 8
        self.col_steps = 16
        self.output_full = (
            self.output_shape[0] * self.frame_stacks + 2 * (self.mem_padding + self.memory_height),
                            self.output_shape[1],
                            self.output_shape[2]
        )

        # Set these in ALL subclasses
        self.action_space = spaces.Discrete(len(self.valid_actions))
        self.observation_space = spaces.Box(low=0, high=255, shape=self.output_full, dtype=np.uint8)

        head = 'headless' if config['headless'] else 'SDL2'

        #log_level("ERROR")
        self.pyboy = PyBoy(
                config['gb_path'],
                debugging=False,
                disable_input=False,
                window_type=head,
                hide_window='--quiet' in sys.argv,
            )

        self.screen = self.pyboy.botsupport_manager().screen()

        if not config['headless']:
            self.pyboy.set_emulation_speed(6)
            
        self.reset()

    def reset(self, seed=None, options=None):
        self.seed = seed
        # restart game, skipping credits
        with open(self.init_state, "rb") as f:
            self.pyboy.load_state(f)
        
        if self.use_screen_explore:
            self.init_knn()
        else:
            self.init_map_mem()

        self.recent_memory = np.zeros((self.output_shape[1]*self.memory_height, 3), dtype=np.uint8)
        
        self.recent_frames = np.zeros(
            (self.frame_stacks, self.output_shape[0], 
             self.output_shape[1], self.output_shape[2]),
            dtype=np.uint8)

        self.agent_stats = []
        
        if self.save_video:
            base_dir = self.s_path / Path('rollouts')
            base_dir.mkdir(exist_ok=True)
            full_name = Path(f'full_reset_{self.reset_count}_id{self.instance_id}').with_suffix('.mp4')
            model_name = Path(f'model_reset_{self.reset_count}_id{self.instance_id}').with_suffix('.mp4')
            self.full_frame_writer = media.VideoWriter(base_dir / full_name, (144, 160), fps=60)
            self.full_frame_writer.__enter__()
            self.model_frame_writer = media.VideoWriter(base_dir / model_name, self.output_full[:2], fps=60)
            self.model_frame_writer.__enter__()
       
        self.levels_satisfied = False
        self.base_explore = 0
        self.max_opponent_level = 0
        self.max_event_rew = 0
        self.max_level_rew = 0
        self.last_health = 1
        self.total_healing_rew = 0
        self.died_count = 0
        self.party_size = 0
        self.step_count = 0
        self.last_item_reward = 0
        self.last_menu_penalty = 0
        self.last_combat_reward = 0
        self.last_area_reward = 0
        self.last_badge_speed_reward = 0
        self.last_hm_reward = 0
        self.last_action = None
        self.last_pokemon_reward = 0
        self.last_heal_reward = 0
        self.last_death_penalty = 0
        self.last_map_penalty = 0
        self.total_healing_rew = 0
        
        self.sum_item_reward = 0
        self.sum_area_reward = 0
        self.sum_badge_reward = 0
        self.sum_hm_reward = 0
        self.sum_combat_reward = 0
        self.sum_menu_penalty = 0
        self.sum_map_penalty = 0
        self.sum_direction_reward = 0
        self.sum_jitter_penalty = 0
        self.sum_pokemon_reward = 0
        self.sum_progress_reward = 0
        
        self.prev_party_size = self.read_m(PARTY_SIZE_ADDRESS)

        # --- ITEM TRACKING ---
        self.prev_money = self.read_money()
        self.prev_item_count = self.get_total_items()

        # --- BADGE SPEED TRACKING ---
        self.badge_times = {}          # badge_index -> best step
        self.prev_badges = self.get_badges()

        # --- AREA SPEED TRACKING ---
        self.map_first_visit_steps = {}  # map_id -> best step

        # --- MENU TRACKING ---
        self.menu_frames = 0
        self.prev_position = (self.read_m(X_POS_ADDRESS), self.read_m(Y_POS_ADDRESS))
        
        # --- MAP TRACKING ---
        self.map_frames = 0
        self.prev_map = self.read_m(MAP_N_ADDRESS)

        # --- BATTLE TRACKING ---
        self.prev_enemy_hp = 1.0

        self.hm_flags = {
            'cut': False,
            'fly': False,
            'surf': False,
            'strength': False,
            'flash': False
        }
        
        # --- SPEEDRUN MILESTONES --- #edited
        self.speedrun_flags = {
            'route1': False,
            'viridian': False,
            'viridian_forest': False,
            'pewter': False,
            'brock': False,
            'mt_moon_enter': False,
            'mt_moon_2f': False,
            'fossil': False,
            'mt_moon_exit': False,
            'pewter_gym': False
        }
        
        self.direction_history = []
        self.recent_actions = []
        self.last_direction = None
        
        self.current_direction = None
        self.direction_run_length = 0
        
        # store for printing
        self.last_jitter_penalty = 0.0
        self.last_direction_reward = 0.0
        self.last_health = self.read_hp_fraction()
        self.prev_enemy_hp = self.read_enemy_hp_fraction()

        self.progress_reward = self.get_game_state_reward()
        self.total_reward = sum([val for _, val in self.progress_reward.items()])
        self.reset_count += 1
                
        return self.render(), {}
    
    def init_knn(self):
        # Declaring index
        self.knn_index = hnswlib.Index(space='l2', dim=self.vec_dim) # possible options are l2, cosine or ip
        # Initing index - the maximum number of elements should be known beforehand
        self.knn_index.init_index(
            max_elements=self.num_elements, ef_construction=100, M=16)
        
    def init_map_mem(self):
        self.seen_coords = {}

    def render(self, reduce_res=True, add_memory=True, update_mem=True):
        game_pixels_render = self.screen.screen_ndarray() # (144, 160, 3)
        if reduce_res:
            game_pixels_render = (255*resize(game_pixels_render, self.output_shape)).astype(np.uint8)
            if update_mem:
                self.recent_frames[0] = game_pixels_render
            if add_memory:
                pad = np.zeros(
                    shape=(self.mem_padding, self.output_shape[1], 3), 
                    dtype=np.uint8)
                game_pixels_render = np.concatenate(
                    (
                        self.create_exploration_memory(), 
                        pad,
                        self.create_recent_memory(),
                        pad,
                        rearrange(self.recent_frames, 'f h w c -> (f h) w c')
                    ),
                    axis=0)
        return game_pixels_render
    
    def step(self, action):

        # -------------------------
        # SAFETY INIT
        # -------------------------
        if not hasattr(self, "last_action"):
            self.last_action = -1
        if not hasattr(self, "direction_run_length"):
            self.direction_run_length = 0
        if not hasattr(self, "direction_history"):
            self.direction_history = []

        # -------------------------
        # PRE-STEP SNAPSHOT
        # -------------------------
        hp_before = self.read_hp_fraction()
        enemy_hp_before = self.prev_enemy_hp

        # -------------------------
        # EXECUTE EMULATOR STEP
        # -------------------------
        self.run_action_on_emulator(action)

        # -------------------------
        # POST-STEP SNAPSHOT
        # -------------------------
        hp_after = self.read_hp_fraction()
        enemy_hp_after = self.read_enemy_hp_fraction()
        self.prev_enemy_hp = enemy_hp_after

        current_items = self.get_total_items()
        current_money = self.read_money()
        current_party_size = self.read_m(PARTY_SIZE_ADDRESS)

        self.party_size = current_party_size
        self.last_health = hp_after

        # -------------------------
        # CORE
        # -------------------------
        self.append_agent_stats(action)

        self.recent_frames = np.roll(self.recent_frames, 1, axis=0)
        obs_memory = self.render()

        frame_start = 2 * (self.memory_height + self.mem_padding)
        obs_flat = obs_memory[
            frame_start:frame_start + self.output_shape[0], ...
        ].flatten().astype(np.float32)

        if self.use_screen_explore:
            self.update_frame_knn_index(obs_flat)
        else:
            self.update_seen_coords()

        # -------------------------
        # HEAL + DEATH
        # -------------------------
        self.update_heal_reward(hp_before, hp_after)

        death_event = (hp_after < 0.01 and hp_before >= 0.01)
        if death_event:
            self.died_count += 1
            self.last_death_penalty = -10.0
        else:
            self.last_death_penalty = 0.0

        # -------------------------
        # BASE REWARD
        # -------------------------
        base_reward, new_prog = self.update_reward()

        # -------------------------
        # AUX REWARDS
        # -------------------------
        r_item = self.item_reward_from_value(current_items, current_money)
        r_badge = self.badge_speed_reward()
        r_area = self.area_speed_reward()
        r_menu = self.menu_penalty()
        r_map = self.same_map_penalty()
        r_hm = self.hm_reward()
        r_speed = self.speedrun_reward()
        r_pokemon = self.pokemon_reward()

        r_combat = (
            self.super_effective_reward(enemy_hp_before, enemy_hp_after) +
            self.ko_reward(enemy_hp_before, enemy_hp_after) +
            self.type_effectiveness_reward(enemy_hp_before, enemy_hp_after)
        )

        # -------------------------
        # DIRECTION
        # -------------------------
        action_is_direction = action in [0, 1, 2, 3]

        direction_penalty = 0.0
        direction_reward = 0.0

        if action_is_direction:
            self.direction_history.append(action)
            if len(self.direction_history) > 12:
                self.direction_history.pop(0)

        # -------------------------
        # RUN LENGTH (STABILIZED)
        # -------------------------
        if action == self.last_action:
            self.direction_run_length += 1
        else:
            # decay instead of reset (prevents reward collapse)
            self.direction_run_length = max(1, self.direction_run_length - 1)

        self.last_action = action

        # -------------------------
        # SMOOTH DIRECTION REWARD (replaces spike system)
        # -------------------------
        direction_reward += min(0.3, self.direction_run_length * 0.01)

        # -------------------------
        # JITTER FIX (INDEPENDENT PENALTY ONLY)
        # -------------------------
        if len(self.direction_history) >= 3:
            # detect back-and-forth oscillation (A → B → A)
            if (self.direction_history[-1] == self.direction_history[-3] and
                self.direction_history[-1] != self.direction_history[-2]):
                direction_penalty -= 0.25
                
        # -------------------------
        # ANTI-JITTER FIX (ADDED TO REWARD)
        # -------------------------
        if len(self.direction_history) >= 7:
            # detect continuos identical inputs
            if (self.direction_history[-1] == self.direction_history[-7] and
                self.direction_history[-1] == self.direction_history[-2] and
                self.direction_history[-2] == self.direction_history[-3] and
                self.direction_history[-3] == self.direction_history[-4] and
                self.direction_history[-4] == self.direction_history[-5] and
                self.direction_history[-5] == self.direction_history[-6]):
                direction_reward += 0.03

        # -------------------------
        # OUTPUT STORAGE
        # -------------------------
        self.last_direction_reward = direction_reward
        self.last_jitter_penalty = direction_penalty

        # =========================================================
        # 🔧 FIXED ACCUMULATORS (THIS WAS THE BUG)
        # =========================================================

        self.last_item_reward = r_item
        self.sum_item_reward += r_item

        self.last_area_reward = r_area
        self.sum_area_reward += r_area

        self.last_badge_speed_reward = r_badge
        self.sum_badge_reward += r_badge

        self.last_hm_reward = r_hm
        self.sum_hm_reward += r_hm

        self.last_combat_reward = r_combat
        self.sum_combat_reward += r_combat

        self.last_menu_penalty = r_menu
        self.sum_menu_penalty += r_menu
        
        self.last_map_penalty = r_map
        self.sum_map_penalty += r_map

        self.last_pokemon_reward = r_pokemon
        self.sum_pokemon_reward += r_pokemon

        self.sum_direction_reward += direction_reward
        self.sum_jitter_penalty += direction_penalty

        # -------------------------
        # FINAL REWARD
        # -------------------------
        extra_reward = (
            r_item + r_badge + r_area +
            r_menu + r_combat + r_hm +
            r_speed + r_pokemon + r_map +
            self.total_healing_rew
        )

        new_reward = (
            base_reward +
            extra_reward +
            direction_reward +
            direction_penalty +
            self.last_death_penalty
        )

        final_reward = float(np.clip(new_reward, -50, 50))

        # -------------------------
        # MEMORY UPDATE
        # -------------------------
        self.recent_memory = np.roll(self.recent_memory, 3)
        self.recent_memory[0, 0] = min(new_prog[0] * 64, 255)
        self.recent_memory[0, 1] = min(new_prog[1] * 64, 255)
        self.recent_memory[0, 2] = min(new_prog[2] * 128, 255)

        done = self.check_if_done()
        self.save_and_print_info(done, obs_memory)

        self.step_count += 1

        return obs_memory, final_reward, False, done, {}

    def run_action_on_emulator(self, action):
        # press button then release after some steps
        self.pyboy.send_input(self.valid_actions[action])
        # disable rendering when we don't need it
        if not self.save_video and self.headless:
            self.pyboy._rendering(False)
        for i in range(self.act_freq):
            # release action, so they are stateless
            if i == 8:
                if action < 4:
                    # release arrow
                    self.pyboy.send_input(self.release_arrow[action])
                if action > 3 and action < 6:
                    # release button 
                    self.pyboy.send_input(self.release_button[action - 4])
                if self.valid_actions[action] == WindowEvent.PRESS_BUTTON_START:
                    self.pyboy.send_input(WindowEvent.RELEASE_BUTTON_START)
            if self.save_video and not self.fast_video:
                self.add_video_frame()
            if i == self.act_freq-1:
                self.pyboy._rendering(True)
            self.pyboy.tick()
        if self.save_video and self.fast_video:
            self.add_video_frame()
    
    def add_video_frame(self):
        self.full_frame_writer.add_image(self.render(reduce_res=False, update_mem=False))
        self.model_frame_writer.add_image(self.render(reduce_res=True, update_mem=False))
    
    def append_agent_stats(self, action):
        x_pos = self.read_m(X_POS_ADDRESS)
        y_pos = self.read_m(Y_POS_ADDRESS)
        map_n = self.read_m(MAP_N_ADDRESS)
        levels = [self.read_m(a) for a in LEVELS_ADDRESSES]
        if self.use_screen_explore:
            expl = ('frames', self.knn_index.get_current_count())
        else:
            expl = ('coord_count', len(self.seen_coords))
        self.agent_stats.append({
            'step': self.step_count, 'x': x_pos, 'y': y_pos, 'map': map_n,
            'map_location': self.get_map_location(map_n),
            'last_action': action,
            'pcount': self.read_m(PARTY_SIZE_ADDRESS), 
            'levels': levels, 
            'levels_sum': sum(levels),
            'ptypes': self.read_party(),
            'hp': self.read_hp_fraction(),
            expl[0]: expl[1],
            'deaths': self.died_count, 'badge': self.get_badges(),
            'event': self.progress_reward['event'], 'healr': self.total_healing_rew
        })

    def update_frame_knn_index(self, frame_vec):
        
        if self.get_levels_sum() >= 22 and not self.levels_satisfied:
            self.levels_satisfied = True
            self.base_explore = self.knn_index.get_current_count()
            self.init_knn()

        if self.knn_index.get_current_count() == 0:
            # if index is empty add current frame
            self.knn_index.add_items(
                frame_vec, np.array([self.knn_index.get_current_count()])
            )
        else:
            # check for nearest frame and add if current 
            labels, distances = self.knn_index.knn_query(frame_vec, k = 1)
            if distances[0][0] > self.similar_frame_dist:
                # print(f"distances[0][0] : {distances[0][0]} similar_frame_dist : {self.similar_frame_dist}")
                self.knn_index.add_items(
                    frame_vec, np.array([self.knn_index.get_current_count()])
                )
    
    def update_seen_coords(self):
        x_pos = self.read_m(X_POS_ADDRESS)
        y_pos = self.read_m(Y_POS_ADDRESS)
        map_n = self.read_m(MAP_N_ADDRESS)
        coord_string = f"x:{x_pos} y:{y_pos} m:{map_n}"
        if self.get_levels_sum() >= 22 and not self.levels_satisfied:
            self.levels_satisfied = True
            self.base_explore = len(self.seen_coords)
            self.seen_coords = {}
        
            self.seen_coords[coord_string] = self.step_count

    def get_total_items(self):
        total = 0
        base_addr = 0xD31E

        for i in range(20):
            item_id = self.read_m(base_addr + i * 2)
            qty = self.read_m(base_addr + i * 2 + 1)

            # STOP ONLY on full terminator, not 0x00 padding
            if item_id == 0xFF:
                break

            # skip empty slots but DO NOT break
            if item_id == 0x00:
                continue

            if 0 < qty <= 99:
                total += qty

        return total
    
    def is_in_menu(self):
        x = self.read_m(X_POS_ADDRESS)
        y = self.read_m(Y_POS_ADDRESS)

        if (x, y) == self.prev_position:
            self.menu_frames += 1
        else:
            self.menu_frames = 0

        self.prev_position = (x, y)

        # ~2 seconds no movement = likely menu/dialog
        return self.menu_frames > 120
    
    def is_in_map(self):
        curr_map = self.read_m(MAP_N_ADDRESS)

        if curr_map == self.prev_map:
            self.map_frames += 1
        else:
            self.map_frames = 0

        self.prev_map = curr_map

        # really too low, but if it was 8 mintues of build up, afraid that's too much
        return self.map_frames > 1000

    def read_enemy_hp_fraction(self):
        # enemy HP addresses (common pattern)
        try:
            hp = 256 * self.read_m(0xCFE6) + self.read_m(0xCFE7)
            max_hp = 256 * self.read_m(0xCFE8) + self.read_m(0xCFE9)
            return hp / max(max_hp, 1)
        except:
            return 1.0

    def update_reward(self):
        # compute reward
        old_prog = self.group_rewards()
        self.progress_reward = self.get_game_state_reward()
        new_prog = self.group_rewards()
        new_total = sum([val for _, val in self.progress_reward.items()]) #sqrt(self.explore_reward * self.progress_reward)
        new_step = new_total - self.total_reward
        if new_step < 0 and self.read_hp_fraction() > 0:
            #print(f'\n\nreward went down! {self.progress_reward}\n\n')
            self.save_screenshot('neg_reward')
    
        self.total_reward = new_total
        return (new_step, 
                   (new_prog[0]-old_prog[0], 
                    new_prog[1]-old_prog[1], 
                    new_prog[2]-old_prog[2])
               )
    
    def group_rewards(self):
        prog = self.progress_reward
        # these values are only used by memory
        return (prog['level'] * 100 / self.reward_scale, 
                self.read_hp_fraction()*2000, 
                prog['explore'] * 300 / (self.explore_weight * self.reward_scale))
               #(prog['events'], 
               # prog['levels'] + prog['party_xp'], 
               # prog['explore'])

    def create_exploration_memory(self):
        w = self.output_shape[1]
        h = self.memory_height

        def make_reward_channel(r_val):
            col_steps = self.col_steps
            max_r_val = (w - 1) * h * col_steps

            r_val = min(r_val, max_r_val)
            row = floor(r_val / (h * col_steps))

            memory = np.zeros(shape=(h, w), dtype=np.uint8)
            memory[:, :row] = 255

            row_covered = row * h * col_steps
            col = floor((r_val - row_covered) / col_steps)

            memory[:col, row] = 255

            col_covered = col * col_steps
            last_pixel = floor(r_val - row_covered - col_covered)

            memory[col, row] = last_pixel * (255 // col_steps)
            return memory

        level, hp, explore = self.group_rewards()

        full_memory = np.stack((
            make_reward_channel(level),
            make_reward_channel(hp),
            make_reward_channel(explore)
        ), axis=-1)

        if self.get_badges() > 0:
            full_memory[:, -1, :] = 255

        return full_memory

    def create_recent_memory(self):
        return rearrange(
            self.recent_memory, 
            '(w h) c -> h w c', 
            h=self.memory_height)

    def check_if_done(self):
        if self.early_stopping:
            done = False
            if self.step_count > 128 and self.recent_memory.sum() < (255 * 1):
                done = True
        else:
            done = self.step_count >= self.max_steps
        #done = self.read_hp_fraction() == 0
        return done

    def save_and_print_info(self, done, obs_memory):

        if self.print_rewards:

            # --- per-step breakdown ---
            step_total = (
                self.last_item_reward +
                self.last_area_reward +
                self.last_badge_speed_reward +
                self.last_hm_reward +
                self.last_combat_reward +
                self.last_pokemon_reward +
                self.last_menu_penalty +
                self.last_map_penalty + 
                self.last_jitter_penalty +
                self.last_direction_reward +
                self.total_healing_rew -
                (0.1 * self.died_count) +   # death penalty
                self.progress_reward['level'] +
                self.progress_reward['explore']
            )

            # --- cumulative total ---
            total_sum = (
                self.sum_item_reward +
                self.sum_area_reward +
                self.sum_badge_reward +
                self.sum_hm_reward +
                self.sum_combat_reward +
                self.sum_menu_penalty +
                self.sum_map_penalty +
                self.sum_direction_reward +
                self.sum_jitter_penalty +
                self.sum_pokemon_reward +
                self.total_healing_rew -
                (0.1 * self.died_count) +
                sum(self.progress_reward.values())
            )

            prog_string = f'step: {self.step_count:6d}'

            prog_string += (
                f' | STEP:{step_total:7.2f}'
                f' | TOTAL:{total_sum:8.2f}'
                f' | heal:{self.last_heal_reward:6.2f}'
                f' | deaths:{self.died_count:3d}'
                f' | death_p:{self.last_death_penalty:5.2f}'
                f' | item:{self.sum_item_reward:6.1f}'
                f' | combat:{self.sum_combat_reward:6.1f}'
                f' | area:{self.sum_area_reward:6.1f}'
                f' | badge:{self.sum_badge_reward:6.1f}'
                f' | hm:{self.sum_hm_reward:6.1f}'
                f' | poke:{self.sum_pokemon_reward:6.1f}'
                f' | menu:{self.sum_menu_penalty:6.1f}'
                f' | map_p:{self.sum_map_penalty:6.1f}'
                f' | dir:{self.sum_direction_reward:5.2f}'
                f' | jit:{self.sum_jitter_penalty:5.2f}'
                f' | expl:{self.progress_reward["explore"]:6.2f}'
            )
  
            print(f'\r{prog_string}', end='', flush=True)
    
    def read_m(self, addr):
        return self.pyboy.get_memory_value(addr)

    def read_bit(self, addr, bit: int) -> bool:
        # add padding so zero will read '0b100000000' instead of '0b0'
        return bin(256 + self.read_m(addr))[-bit-1] == '1'
    
    def get_levels_sum(self):
        poke_levels = [max(self.read_m(a) - 2, 0) for a in LEVELS_ADDRESSES]
        return max(sum(poke_levels) - 4, 0) # subtract starting pokemon level
    
    def get_levels_reward(self):
        explore_thresh = 22
        scale_factor = 4
        level_sum = self.get_levels_sum()
        if level_sum < explore_thresh:
            scaled = level_sum
        else:
            scaled = (level_sum-explore_thresh) / scale_factor + explore_thresh
        self.max_level_rew = max(self.max_level_rew, scaled)
        return self.max_level_rew
    
    def get_knn_reward(self):
        
        pre_rew = self.explore_weight * 0.09
        post_rew = self.explore_weight * 0.15
        cur_size = self.knn_index.get_current_count() if self.use_screen_explore else len(self.seen_coords)
        base = (self.base_explore if self.levels_satisfied else cur_size) * pre_rew
        post = (cur_size if self.levels_satisfied else 0) * post_rew
        return base + post
    
    def get_badges(self):
        return self.bit_count(self.read_m(BADGE_COUNT_ADDRESS))

    def read_party(self):
        return [self.read_m(addr) for addr in PARTY_ADDRESSES]
    
    def update_heal_reward(self, hp_before, hp_after):
        heal_amount = hp_after - hp_before

        # detect normal healing
        if heal_amount > 0.01:
            reward = heal_amount * 200

            self.total_healing_rew += reward
            self.last_heal_reward = reward
            return

        # ----------------------------
        # FIX: detect burst healing (potion / pokemon center)
        # ----------------------------

        # big sudden jump = heal event even if split across frames
        if hp_after >= 0.95 and hp_before < 0.95:
            reward = 15.0
            self.total_healing_rew += reward
            self.last_heal_reward = reward
            return

        # mid-range recovery detection (potion / partial heal spam)
        if hp_after > hp_before and (hp_after - hp_before) < 0.01:
            # small trickle healing still counts if sustained
            reward = 5.0
            self.total_healing_rew += reward
            self.last_heal_reward = reward
            return

        self.last_heal_reward = 0.0
                
    def ko_reward(self, prev_hp, curr_hp):
        if prev_hp > 0 and curr_hp == 0:
            return 0.3
        return 0.0	
    
    def type_effectiveness_reward(self, prev_hp, curr_hp):
        hp_drop = max(0, prev_hp - curr_hp)

        if hp_drop > 0.25:
            return 0.2
        elif hp_drop > 0.15:
            return 0.02
        return 0.0

    def pokemon_reward(self):
        reward = 0

        current_size = self.read_m(PARTY_SIZE_ADDRESS)

        if current_size > self.prev_party_size:
            reward += 10.0  # strong reward for catching Pokémon

        self.prev_party_size = current_size
        return reward

    def hm_reward(self):
        reward = 0

        hm_checks = {
            'cut': (0xD803, 0),
            'fly': (0xD804, 0),
            'surf': (0xD80C, 0),
            'strength': (0xD80E, 0),
            'flash': (0xD810, 0),
        }

        for hm, (addr, bit) in hm_checks.items():
            has_hm = self.read_bit(addr, bit)

            if has_hm and not self.hm_flags[hm]:
                self.hm_flags[hm] = True
                reward += 20.0   # BIG reward (progress unlock)

        self.last_hm_reward = reward
        return reward
    
    def speedrun_reward(self): #edited
        reward = 0
        steps = self.step_count
        map_id = self.read_m(MAP_N_ADDRESS)
        badges = self.get_badges()

        # helper
        def check(flag, condition, target_steps):
            nonlocal reward
            if not self.speedrun_flags[flag] and condition:
                self.speedrun_flags[flag] = True

                if steps <= target_steps:
                    reward += 20
                elif steps <= target_steps * 2:
                    reward += 10

        # --- milestones ---

        # Route 1
        check('route1', map_id == 12, 425 + 1500)

        # Viridian City
        check('viridian', map_id == 1, 475 + 1500)

        # Viridian Forest
        check('viridian_forest', map_id == 51, 1125)

        # Pewter City
        check('pewter', map_id == 2, 1425)
        
        # Enter Pewter Gym
        check('pewter_gym', map_id == 54, 1600 + 500)

        # Brock defeated (badge 1)
        check('brock', badges >= 1, 1700)
        
        # --- MT MOON (BUFFED MILESTONE ZONE) ---

        # Enter Mt Moon
        check('mt_moon_enter', map_id == 59, 2700 + 500)

        # Deeper floors
        check('mt_moon_2f', map_id in [60, 61], 2900 + 750)

        # Fossil obtained (event flag proxy)
        fossil_flag = (
            self.read_bit(0xD7F6, 0) or
            self.read_bit(0xD7F6, 1)
        )  # may need adjustment
        check('fossil', fossil_flag, 3500 + 1000)

        # Exit Mt Moon (Route 4)
        check('mt_moon_exit', map_id == 15, 3550 + 750)

        return reward

    def item_reward_from_value(self, current_items, current_money):
        reward = 0

        item_diff = current_items - self.prev_item_count
        money_diff = current_money - self.prev_money

        if item_diff > 0:
            reward += 2.0 * item_diff

        if money_diff < -50:
            reward -= 0.5 * item_diff

        self.prev_item_count = current_items
        self.prev_money = current_money

        return reward

    def badge_speed_reward(self):
        reward = 0

        current_badges = self.get_badges()

        if current_badges > self.prev_badges:
            badge_index = current_badges  # simple ordering
            steps = self.step_count

            if badge_index not in self.badge_times:
                self.badge_times[badge_index] = steps
                reward += 50  # first time bonus
            else:
                best_time = self.badge_times[badge_index]
                if steps < best_time:
                    reward += (best_time - steps) * 0.1
                    self.badge_times[badge_index] = steps

        self.prev_badges = current_badges
        return reward

    def area_speed_reward(self):
        reward = 0

        current_map = self.read_m(MAP_N_ADDRESS)
        steps = self.step_count

        if current_map not in self.map_first_visit_steps:
            self.map_first_visit_steps[current_map] = steps
            reward += 5  # discovery bonus
        else:
            best_time = self.map_first_visit_steps[current_map]
            if steps < best_time:
                reward += (best_time - steps) * 0.05
                self.map_first_visit_steps[current_map] = steps

        return reward

    def menu_penalty(self):
        penalty = 0

        if self.is_in_menu():
            if self.menu_frames > 60 * 60 * 1: #edited
                penalty -= 5.0
                
            # slow scaling after threshold
                penalty -= 0.0005 * (self.menu_frames - 60 * 60 * 1)

        self.last_menu_penalty = penalty
        return penalty
    
    def same_map_penalty(self):
        same_map_penalty = 0
        
        if self.is_in_map():
            if self.map_frames > 60 * 60 * 8: #edited
                same_map_penalty -= 1.0
                
                # slow scaling after threshold
                same_map_penalty -= 0.0005 * (self.map_frames - 60 * 60 * 8)

        self.last_map_penalty = same_map_penalty
 
        return same_map_penalty

    def super_effective_reward(self, prev_hp, curr_hp):
        hp_drop = max(0, prev_hp - curr_hp)
        return hp_drop * 0.2 if hp_drop > 0.1 else 0.0
                
    def get_all_events_reward(self):
        # adds up all event flags, exclude museum ticket
        event_flags_start = EVENT_FLAGS_START_ADDRESS
        event_flags_end = EVENT_FLAGS_END_ADDRESS
        museum_ticket = (MUSEUM_TICKET_ADDRESS, 0)
        base_event_flags = 13
        return max(
            sum(
                [
                    self.bit_count(self.read_m(i))
                    for i in range(event_flags_start, event_flags_end)
                ]
            )
            - base_event_flags
            - int(self.read_bit(museum_ticket[0], museum_ticket[1])),
        0,
    )

    def get_game_state_reward(self, print_stats=False):
        # addresses from https://datacrystal.romhacking.net/wiki/Pok%C3%A9mon_Red/Blue:RAM_map
        # https://github.com/pret/pokered/blob/91dc3c9f9c8fd529bb6e8307b58b96efa0bec67e/constants/event_constants.asm
        '''
        num_poke = self.read_m(0xD163)
        poke_xps = [self.read_triple(a) for a in [0xD179, 0xD1A5, 0xD1D1, 0xD1FD, 0xD229, 0xD255]]
        #money = self.read_money() - 975 # subtract starting money
        seen_poke_count = sum([self.bit_count(self.read_m(i)) for i in range(0xD30A, 0xD31D)])
        all_events_score = sum([self.bit_count(self.read_m(i)) for i in range(0xD747, 0xD886)])
        oak_parcel = self.read_bit(0xD74E, 1) 
        oak_pokedex = self.read_bit(0xD74B, 5)
        opponent_level = self.read_m(0xCFF3)
        self.max_opponent_level = max(self.max_opponent_level, opponent_level)
        enemy_poke_count = self.read_m(0xD89C)
        self.max_opponent_poke = max(self.max_opponent_poke, enemy_poke_count)
        
        if print_stats:
            print(f'num_poke : {num_poke}')
            print(f'poke_levels : {poke_levels}')
            print(f'poke_xps : {poke_xps}')
            #print(f'money: {money}')
            print(f'seen_poke_count : {seen_poke_count}')
            print(f'oak_parcel: {oak_parcel} oak_pokedex: {oak_pokedex} all_events_score: {all_events_score}')
        '''
        
        state_scores = {
            'event': self.reward_scale*self.update_max_event_rew(),  
            #'party_xp': self.reward_scale*0.1*sum(poke_xps),
            'level': self.reward_scale*self.get_levels_reward(), 
            'heal': self.reward_scale*self.total_healing_rew,
            'op_lvl': self.reward_scale*self.update_max_op_level(),
            'dead': self.reward_scale*-0.1*self.died_count,
            'badge': self.reward_scale*self.get_badges() * 5,
            #'op_poke': self.reward_scale*self.max_opponent_poke * 800,
            #'money': self.reward_scale* money * 3,
            #'seen_poke': self.reward_scale * seen_poke_count * 400,
            'explore': self.reward_scale * self.get_knn_reward() * 5
        }
        
        return state_scores
    
    def save_screenshot(self, name):
        ss_dir = self.s_path / Path('screenshots')
        ss_dir.mkdir(exist_ok=True)
        plt.imsave(
            ss_dir / Path(f'frame{self.instance_id}_r{self.total_reward:.4f}_{self.reset_count}_{name}.jpeg'), 
            self.render(reduce_res=False))
    
    def update_max_op_level(self):
        #opponent_level = self.read_m(0xCFE8) - 5 # base level
        opponent_level = max([self.read_m(a) for a in OPPONENT_LEVELS_ADDRESSES]) - 5
        #if opponent_level >= 7:
        #    self.save_screenshot('highlevelop')
        self.max_opponent_level = max(self.max_opponent_level, opponent_level)
        return self.max_opponent_level * 0.2
    
    def update_max_event_rew(self):
        cur_rew = self.get_all_events_reward()
        self.max_event_rew = max(cur_rew, self.max_event_rew)
        return self.max_event_rew

    def read_hp_fraction(self):
        party_size = self.read_m(PARTY_SIZE_ADDRESS)

        hp_sum = 0
        max_hp_sum = 0

        for i in range(party_size):
            hp_sum += self.read_hp(HP_ADDRESSES[i])
            max_hp_sum += self.read_hp(MAX_HP_ADDRESSES[i])

        max_hp_sum = max(max_hp_sum, 1)
        return hp_sum / max_hp_sum

    def read_hp(self, start):
        return 256 * self.read_m(start) + self.read_m(start+1)

    # built-in since python 3.10
    def bit_count(self, bits):
        return bin(bits).count('1')

    def read_triple(self, start_add):
        return 256*256*self.read_m(start_add) + 256*self.read_m(start_add+1) + self.read_m(start_add+2)
    
    def read_bcd(self, num):
        return 10 * ((num >> 4) & 0x0f) + (num & 0x0f)
    
    def read_money(self):
        return (100 * 100 * self.read_bcd(self.read_m(MONEY_ADDRESS_1)) + 
                100 * self.read_bcd(self.read_m(MONEY_ADDRESS_2)) +
                self.read_bcd(self.read_m(MONEY_ADDRESS_3)))

    def get_map_location(self, map_idx):
        map_locations = {
            0: "Pallet Town",
            1: "Viridian City",
            2: "Pewter City",
            3: "Cerulean City",
            12: "Route 1",
            13: "Route 2",
            14: "Route 3",
            15: "Route 4",
            33: "Route 22",
            37: "Red house first",
            38: "Red house second",
            39: "Blues house",
            40: "oaks lab",
            41: "Pokémon Center (Viridian City)",
            42: "Poké Mart (Viridian City)",
            43: "School (Viridian City)",
            44: "House 1 (Viridian City)",
            47: "Gate (Viridian City/Pewter City) (Route 2)",
            49: "Gate (Route 2)",
            50: "Gate (Route 2/Viridian Forest) (Route 2)",
            51: "viridian forest",
            52: "Pewter Museum (floor 1)",
            53: "Pewter Museum (floor 2)",
            54: "Pokémon Gym (Pewter City)",
            55: "House with disobedient Nidoran♂ (Pewter City)",
            56: "Poké Mart (Pewter City)",
            57: "House with two Trainers (Pewter City)",
            58: "Pokémon Center (Pewter City)",
            59: "Mt. Moon (Route 3 entrance)",
            60: "Mt. Moon",
            61: "Mt. Moon",
            68: "Pokémon Center (Route 4)",
            193: "Badges check gate (Route 22)"
        }
        if map_idx in map_locations.keys():
            return map_locations[map_idx]
        else:
            return "Unknown Location"
    
